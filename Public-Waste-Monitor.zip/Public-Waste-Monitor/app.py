import os
import uuid

from flask import Flask, render_template, request, redirect, session
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from database import get_connection, create_table


app = Flask(__name__)

app.secret_key = "change-this-to-a-private-random-key"

# Image upload settings
UPLOAD_FOLDER = os.path.join(app.root_path, "static", "uploads")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


# Create database tables
create_table()


# Home page
@app.route("/")
def home():
    return render_template("index.html")


# User registration
@app.route("/register", methods=["GET", "POST"])
def register():

    error = None

    if request.method == "POST":

        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]

        hashed_password = generate_password_hash(password)

        connection = get_connection()

        try:
            connection.execute(
                """
                INSERT INTO users (name, email, password)
                VALUES (?, ?, ?)
                """,
                (name, email, hashed_password)
            )

            connection.commit()
            connection.close()

            return redirect("/login")

        except Exception:
            connection.close()
            error = "This email may already be registered."

    return render_template("register.html", error=error)


# User login
@app.route("/login", methods=["GET", "POST"])
def login():

    error = None

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        connection = get_connection()

        user = connection.execute(
            "SELECT * FROM users WHERE email = ?",
            (email,)
        ).fetchone()

        connection.close()

        if user and check_password_hash(user["password"], password):

            session["user_id"] = user["id"]
            session["name"] = user["name"]

            return redirect("/dashboard")

        else:
            error = "Invalid email or password."

    return render_template("login.html", error=error)


# Citizen dashboard
@app.route("/dashboard")
def dashboard():

    if "user_id" not in session:
        return redirect("/login")

    return render_template(
        "dashboard.html",
        name=session["name"]
    )


# Report waste complaint
@app.route("/report", methods=["GET", "POST"])
def report():

    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":

        category = request.form.get("category", "").strip()
        location = request.form.get("location", "").strip()
        description = request.form.get("description", "").strip()

        if not category or not location or not description:
            return render_template(
                "report.html",
                error="Please fill in all required fields."
            )

        image = request.files.get("image")
        image_filename = None

        if image and image.filename:

            if not allowed_file(image.filename):
                return render_template(
                    "report.html",
                    error="Only JPG, JPEG, PNG and WEBP images are allowed."
                )

            extension = secure_filename(image.filename).rsplit(".", 1)[1].lower()

            image_filename = f"{uuid.uuid4().hex}.{extension}"

            image.save(
                os.path.join(
                    app.config["UPLOAD_FOLDER"],
                    image_filename
                )
            )

        connection = get_connection()

        connection.execute(
            """
            INSERT INTO complaints
            (user_id, category, location, description, image)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                session["user_id"],
                category,
                location,
                description,
                image_filename
            )
        )

        connection.commit()
        connection.close()

        return render_template(
            "report.html",
            success="Your waste complaint has been submitted successfully!"
        )

    return render_template("report.html")


# User logout
@app.route("/logout")
def logout():

    session.clear()

    return redirect("/login")


# Run application
if __name__ == "__main__":
    app.run(debug=True)